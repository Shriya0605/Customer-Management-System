﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
     public class e_billingitem
    {
        public int id { get; set; }
        public int billingid { get; set; }
        public int itemid { get; set; }
        public int qty { get; set; }
        public float price { get; set; }
        public int uomid { get; set; }
        public bool isactive { get; set; }
  
    }
}
