﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
   public class e_subCategory
    {
        public int id { get; set; }
        public int categoryid { get; set; }
        public string subcategorycode { get; set; }
        public string subcategoryname { get; set; }
        public bool isactive { get; set; }
 
    }
}
