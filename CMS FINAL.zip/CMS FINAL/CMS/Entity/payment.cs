﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class e_payment
    {
        public int id { get; set; }
        public int billingid { get; set; }
        public float paidamount { get; set; }
        public DateTime paiddate { get; set; }
        public int paymentrefno { get; set; }
        public bool isactive { get; set; }
   
    }
}
