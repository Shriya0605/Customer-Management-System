﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class e_billing
    {
        public int id { get; set; }
        public string billno { get; set; }
        public string invoicedate { get; set; }
        public int customerid { get; set; }
        public bool isactive { get; set; }
    }
}
