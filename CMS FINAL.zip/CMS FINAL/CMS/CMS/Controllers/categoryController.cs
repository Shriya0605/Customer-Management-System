﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;

namespace CMS.Controllers
{
    public class categoryController : Controller
    {
        //
        // GET: /category/

        public ActionResult Index()
        {
            category cat = new category();
            List<e_category> lstentCat = new CategoryBusiness().GetAllCategories();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View(cat);
        }

        private List<category> ConvertToModelCategory(List<e_category> lstentCat)
        {
            List<category> lstCat = new List<category>();
            foreach (var item in lstentCat)
            {
                lstCat.Add(new category
                {
                    id = item.id,
                    categoryname=item.categoryname,
                    categorycode=item.categorycode,
                    isActive = item.isActive
                });
            }
            return lstCat;
        }
        [HttpPost]
        public ActionResult SaveCategory(category cat)
        {
            e_category Cat = new e_category();
            Cat.id = cat.id;
            Cat.categoryname = cat.categoryname;
            Cat.categorycode = cat.categorycode;
            Cat.isActive = cat.isActive;
            CategoryBusiness cb = new CategoryBusiness();
            cb.SaveCategory(Cat);

            cat = new category();
            List<e_category> lstentCat = new CategoryBusiness().GetAllCategories();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View("Index", cat);
        }

        public ActionResult ModelNull(category catlst)
        {
            return View("Index", new category());
        }


        public ActionResult DeleteCategory(int id)
        {
            CategoryBusiness cb = new CategoryBusiness();
            cb.DeleteCategory(id);


            List<e_category> lstentCat= new CategoryBusiness().GetAllCategories();
            category cat = new category();
            cat.lstcategory = ConvertToModelCategory(lstentCat);
            return View("Index", cat);
        }

        public ActionResult FindCategoryById(int id)
        {
            List<e_category> lstCat = new CategoryBusiness().GetCategoryById(id);
            return View("Index", ConvertToModelCategory(lstCat)[0]);
        }





        public ActionResult SearchCategory(string categoryname, string categorycode)
        {

            CategoryBusiness cb = new CategoryBusiness();
            List<e_category> listCat = cb.SearchCategory(categoryname, categorycode);
            category cat = new category();
            cat.lstcategory = ConvertToModelCategory(listCat);
            return View("Index", cat);
        }

    }
}
