﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CMS.Models;
using Entity;
using Business;

namespace CMS.Controllers
{
    public class billingController : Controller
    {
        //
        // GET: /billing/

        public ActionResult Index()
        {
            billing bil = new billing();
            List<e_billing> lstentBill = new billingBusiness().getAllBillings();
            bil.lstBilling = ConvertToModelBilling(lstentBill);
            return View(bil);
        }

        private List<billing> ConvertToModelBilling(List<e_billing> lstentBill)
        {
            List<billing> lstBill = new List<billing>();
            foreach (var item in lstentBill)
            {
                lstBill.Add(new billing
                {
                    id = item.id,
                    billno=item.billno,
                    invoicedate=item.invoicedate,
                    customerid=item.customerid,
                    isactive = item.isactive
                    
                });
            }
            return lstBill;
        }

        public ActionResult SaveBill(billing bill)
        {
            e_billing bil = new e_billing();
            bil.id = bill.id;
            bil.billno = bill.billno;
            bil.invoicedate = bill.invoicedate;
            bil.customerid = bill.customerid;
            bil.isactive = bill.isactive;
            billingBusiness bb = new billingBusiness();
            bb.SaveBill(bil);

            bill = new billing();
            List<e_billing> lstentBill = new billingBusiness().getAllBillings();
            bill.lstBilling = ConvertToModelBilling(lstentBill);
            return View("Index", bill);
        }

        public ActionResult DeleteBill(int id)
        {
            billingBusiness bb = new billingBusiness();
            bb.deleteBilling(id);


            List<e_billing> lstentBill = new billingBusiness().getAllBillings();
            billing bil = new billing();
            bil.lstBilling = ConvertToModelBilling(lstentBill);
            return View("Index", bil);
        }

        public ActionResult FindBillById(int id)
        {
            List<e_billing> lstbil = new billingBusiness().getBillingById(id);
            return View("Index", ConvertToModelBilling(lstbil)[0]);
        }

        public ActionResult ModelNull(billing lstBill)
        {
            return View("Index", new billing());
        }



        public ActionResult SearchBill(string billno, string invoicedate)
        {

            billingBusiness bb = new billingBusiness();
            List<e_billing> listBill = bb.SearchBill(billno, invoicedate);
            billing bil = new billing();
            bil.lstBilling = ConvertToModelBilling(listBill);
            return View("Index", bil);
        }

    }
}
