﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Entity;
using Business;
using CMS.Models;

namespace CMS.Controllers
{
    public class companyController : Controller
    {
        //
        // GET: /company/

        public ActionResult Index()
        {
            company comp = new company();
            List<e_company> lstentCompany = new CompanyBusiness().getAllCompanies();
            comp.lstComp = ConvertToModelCompany(lstentCompany);
            return View(comp);
        }

        private List<company> ConvertToModelCompany(List<e_company> lstentCompany)
        {
            List<company> lstComp = new List<company>();
            foreach (var item in lstentCompany)
            {
                lstComp.Add(new company
                {
                   id=item.id,
                   companyName = item.companyName,
                   address = item.address,
                   email = item.address,
                   gstno = item.gstno,
                   contactno = item.contactno,
                   isActive = item.isActive

                });
            }
            return lstComp;
        }

        [HttpPost]
        public ActionResult SaveCompany(company comp)
        {
            e_company ecomp = new e_company();
            comp.id = ecomp.id;
            comp.companyName = ecomp.companyName;
            comp.address = ecomp.address;
            comp.gstno = ecomp.gstno;
            comp.contactno = ecomp.contactno;
            comp.isActive = ecomp.isActive;
            CompanyBusiness cb = new CompanyBusiness();
            cb.SaveCompany(ecomp);

            comp = new company();
            List<e_company> lstentCompany = new CompanyBusiness().getAllCompanies();
            comp.lstComp = ConvertToModelCompany(lstentCompany);
            return View("Index", comp);
        }

        public ActionResult DeleteCompany(int id)
        {
            CompanyBusiness cb = new CompanyBusiness();
            cb.deleteCompany(id);

            List<e_company> lstentComp = new CompanyBusiness().getAllCompanies();
            company comp = new company();
            comp.lstComp = ConvertToModelCompany(lstentComp);
            return View("Index", comp);
        }

        public ActionResult FindCompanyById(int id)
        {
            List<e_company> lstComp = new CompanyBusiness().getCompanyByID(id);
            return View("Index", ConvertToModelCompany(lstComp)[0]);
        }

        public ActionResult ModelNull(company lstComp)
        {
            return View("Index", new company());
        }



        public ActionResult SearchCompanyByCompanyNameAndEmail(string companyname, string email)
        {

            CompanyBusiness cb = new CompanyBusiness();
            List<e_company> listComp = cb.SearchCompany(companyname, email);
            company com = new company();
            com.lstComp = ConvertToModelCompany(listComp);
            return View("Index", com);
        }

    }
}
