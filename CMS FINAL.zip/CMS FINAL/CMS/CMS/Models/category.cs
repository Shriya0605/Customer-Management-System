﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class category
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Category Name")]
        public string categoryname { get; set; }
        [Required]
        [Display(Name = "Category Code")]
        public string categorycode { get; set; }
        [Required]
        [Display(Name = "IS Active")]
        public bool isActive { get; set; }
        public List<category> lstcategory { get; set; }
   
    }
}
