﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class item
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "Category")]
        public int categoryid { get; set; }
        [Required]
        [Display(Name = "Sub Category")]
        public int subcategoryid { get; set; }
        [Required]
        [Display(Name = "Product Name")]
        public string productname { get; set; }
        [Required]
        [Display(Name = "Product Code")]
        public string productcode { get; set; }
        [Required]
        [Display(Name = "IS ACTIVE")]
        public bool isactive { get; set; }
        public List<item> lstItem { get; set; }
    }
}
