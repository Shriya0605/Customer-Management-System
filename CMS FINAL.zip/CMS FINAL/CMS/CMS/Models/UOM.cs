﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CMS.Models
{
    public class UOM
    {
        public int id { get; set; }
        [Required]
        [Display(Name = "UOM Name")]
        public string UOMName { get; set; }
        [Required]
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
        public List<UOM> lstUOM { get; set; }
    
    }
}
