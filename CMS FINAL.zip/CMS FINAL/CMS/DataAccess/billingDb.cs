﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class billingDb
    {
        SqlConnection sqlCon = new SqlConnection( ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);
        public long DeleteBilling(int id)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    //To assign connextion object to command
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.STORED_PROCEDURE_DELETE_BILLING;
                    //Adding Parameter into Command
                    cmd.Parameters.AddWithValue("@id", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_billing> GetAllBillings()
        {
            List<e_billing> lstBill = new List<e_billing>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllBillings;
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billing bill = new e_billing();
                        bill.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.billno = reader.GetValue(1).ToString();
                        bill.invoicedate = reader.GetValue(2).ToString();
                        bill.customerid =Convert.ToInt32( reader.GetValue(3).ToString());
                        bill.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }

        public List<e_billing> GetBillById(int id)
        {
            List<e_billing> lstBill = new List<e_billing>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetBillingById;
                    cmd.Parameters.AddWithValue("@id", id);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billing bill = new e_billing();
                        bill.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.billno = reader.GetValue(1).ToString();
                        bill.invoicedate = reader.GetValue(2).ToString();
                        bill.customerid = Convert.ToInt32(reader.GetValue(3).ToString());
                        bill.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }


        public long InsertBilling(e_billing bill)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertBilling;
                    //cmd.Parameters.AddWithValue("@ID", bill.id);
                    cmd.Parameters.AddWithValue("@billno", bill.billno);
                    cmd.Parameters.AddWithValue("@invoicedate", bill.invoicedate);
                    cmd.Parameters.AddWithValue("@customerid", bill.customerid);
                    cmd.Parameters.AddWithValue("@isactive", bill.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public long UpdateBilling(e_billing bill)
        {
            long result = 0;
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateBilling;
                    cmd.Parameters.AddWithValue("@ID", bill.id);
                    cmd.Parameters.AddWithValue("@billno", bill.billno);
                    cmd.Parameters.AddWithValue("@invoicedate", bill.invoicedate);
                    cmd.Parameters.AddWithValue("@customerid", bill.customerid);
                    cmd.Parameters.AddWithValue("@isactive", bill.isactive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

        public List<e_billing> SearchBill(string billno,string invoicedate)
        {
            List<e_billing> lstBill = new List<e_billing>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_SearchByBillNoAndInvoiceDate;
                    cmd.Parameters.AddWithValue("@billno", billno);
                    cmd.Parameters.AddWithValue("@invoicedate", invoicedate);
                    //sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_billing bill = new e_billing();
                        bill.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        bill.billno = reader.GetValue(1).ToString();
                        bill.invoicedate = reader.GetValue(2).ToString();
                        bill.customerid = Convert.ToInt32(reader.GetValue(3).ToString());
                        bill.isactive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstBill.Add(bill);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstBill;
        }


    }
}
