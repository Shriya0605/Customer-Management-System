﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data.Sql;
using System.Configuration;
using System.Data;
using Common;
using Entity;

namespace DataAccess
{
    public class userDB
    {

        long result = 0;
        SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["CONSTR"].ConnectionString);


        public long DeleteUser(int id)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_DeleteUser;
                    cmd.Parameters.AddWithValue("@ID", id);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public List<e_user> GetAllUsers()
        {
            List<e_user> lstUser = new List<e_user>();
                    
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    sqlCon.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetAllUsers;
                    //sqlCon.Open();
                   // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_user usr = new e_user();
                        usr.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        usr.username = reader.GetValue(1).ToString();
                        usr.password = reader.GetValue(2).ToString();
                        usr.userRole = reader.GetValue(3).ToString();
                        usr.isActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstUser.Add(usr);
                    }
                    reader.Close();
                    
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUser;
        }


        public List<e_user> GetUserByID(int id)
        {
            List<e_user> lstUser = new List<e_user>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_GetUserById;
                    cmd.Parameters.AddWithValue("@id",id);
                    sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_user usr = new e_user();
                        usr.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        usr.username = reader.GetValue(1).ToString();
                        usr.password = reader.GetValue(2).ToString();
                        usr.userRole = reader.GetValue(3).ToString();
                        usr.isActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstUser.Add(usr);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUser;
        }

        public List<e_user> SearchUser(string username,string userrole)
        {
            List<e_user> lstUser = new List<e_user>();

            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "SelectByUserNameANDUserRole";
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@userrole", userrole);
                    sqlCon.Open();
                    // result = cmd.ExecuteNonQuery();
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        e_user usr = new e_user();
                        usr.id = Convert.ToInt32(reader.GetValue(0).ToString());
                        usr.username = reader.GetValue(1).ToString();
                        usr.password = reader.GetValue(2).ToString();
                        usr.userRole = reader.GetValue(3).ToString();
                        usr.isActive = Convert.ToBoolean(reader.GetValue(4).ToString() == "1" ? true : false);
                        lstUser.Add(usr);
                    }
                    reader.Close();

                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return lstUser;
        }


        public long InsertUser(e_user user)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_InsertUser;
                    //cmd.Parameters.AddWithValue("@ID", user.id);
                    cmd.Parameters.AddWithValue("@Username", user.username);
                    cmd.Parameters.AddWithValue("@Password", user.password);
                    cmd.Parameters.AddWithValue("@Userrole", user.userRole);
                    cmd.Parameters.AddWithValue("@IsActive", user.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }


        public long UpdateUser(e_user user)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    cmd.Connection = sqlCon;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = Constants.SP_UpdateUser;
                    cmd.Parameters.AddWithValue("@id", user.id);
                    cmd.Parameters.AddWithValue("@username", user.username);
                    cmd.Parameters.AddWithValue("@password", user.password);
                    cmd.Parameters.AddWithValue("@userrole", user.userRole);
                    cmd.Parameters.AddWithValue("@isactive", user.isActive);
                    sqlCon.Open();
                    result = cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                sqlCon.Close();
            }
            return result;
        }

    }

}
