﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using DataAccess;
using Entity;

namespace Business
{
    public class billingBusiness
    {

        billingDb db = new billingDb();


        public List<e_billing> getAllBillings()
        {
            return db.GetAllBillings();
        }


        public List<e_billing> getBillingById(int id)
        {
            return db.GetBillById(id);
        }


        public void updateBilling(e_billing bill)
        {
            db.UpdateBilling(bill);
        }


        public void deleteBilling(int id)
        {
            db.DeleteBilling(id);
        }


        public void SaveBill(e_billing bill)
        {
            if (bill.id > 0)
            {
                db.UpdateBilling(bill);
            }
            else
            {
                db.InsertBilling(bill);
            }
        }
        public List<e_billing> SearchBill(string billno, string invoicedate)
        {
            return db.SearchBill(billno,invoicedate);
        }
    }
}
