﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Common;
using DataAccess;
using Entity;


namespace Business
{
   public class CompanyBusiness
    {

        companyDB db = new companyDB();


        public List<e_company> getAllCompanies()
        {
            return db.GetAllCompanies();
        }


        public List<e_company> getCompanyByID(int id)
        {
            return db.GetCompanyByID(id);
        }

        public List<e_company> SearchCompany(string companyname, string email)
        {
            return db.SearchCompany(companyname, email);
        }


        public void updateCompany(e_company com)
        {
            db.UpdateCompany(com);
        }


        public void deleteCompany(int id)
        {
            db.DeleteCompany(id);
        }


        public void SaveCompany(e_company comp)
        {
            if (comp.id > 0)
            {
                db.UpdateCompany(comp);
            }
            else
            {
                db.InsertCompany(comp);
            }
        }
    }

}
